package org.bouncycastle.operator;

public interface OutputAEADEncryptor
    extends OutputEncryptor, AADProcessor
{

}

