package org.bouncycastle.openssl;

public class PasswordException
    extends PEMException
{
    public PasswordException(String msg)
    {
        super(msg);
    }
}
